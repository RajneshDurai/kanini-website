function f1()
{
    let name=document.getElementById("name").value;
    let mail=document.getElementById("mail").value;
    let phno=document.getElementById("ph1").value;
    let role=document.getElementById("role").value;
    let yoe=document.getElementById("yoe").value;
    let skill=document.getElementById("skill").value;
    let dob=document.getElementById("dob").value;
    let gen=document.getElementById("gen").value;
    let ph2=document.getElementById("ph2").value;
    let cname=document.getElementById("cname").value;
    let ct1=document.getElementById("ct1").value;
    let ct2=document.getElementById("ct2").value;

    let check=name.match(/[A-Za-z\s]/g);
    let date=dob.match(/[0-9]/g);
    let echeck=mail.match(/[a-z0-9@gmail.com]/g);
    let phcheck=phno.match(/[0-9]/g);
    let phcheck2=ph2.match(/[0-9]/g);
    let gend=gen.match(/[A-Za-z]/g);

    let check2=cname.match(/[A-Za-z]/g);
    let jcheck=role.match(/[A-Za-z]/g);
    let yrcheck=yoe.match(/[0-9]/g);
    let sklcheck=skill.match(/[A-Za-z]/g);
    let ctc1=ct1.match(/[0-9A-Z]/g);
    let ctc2=ct2.match(/[0-9A-Z]/g);

    if(name.match(/[A-Za-z\s]/g)== null || name.match(check))
    {
        document.getElementById("nm").style.display="block";
        document.getElementById("nm").innerHTML='Please Fill it';
    }
    if(dob.match(/[0-9]/g)==null)
    {
        document.getElementById("db").style.display="block";
        document.getElementById("db").innerHTML='Please Fill it';
    }

    if(mail.match(/[a-z0-9@gmail.com]/g)==null || mail.match(echeck))
    {
        document.getElementById("eml").style.display="block";
        document.getElementById("eml").innerHTML='Please Fill it';
    }

    if(phno.match(/[0-9]/g)==null || phno.match(phcheck))
    {
        document.getElementById("num").style.display="block";
        document.getElementById("num").innerHTML='Please Fill it';
    }

    if(ph2.match(/[0-9]/g)==null || ph2.match(phcheck2))
    {
        document.getElementById("num2").style.display="block";
        document.getElementById("num2").innerHTML='Please Fill it';
    }

    if(gen.match(/[A-Za-z]/g)==null || gen.match(gend))
    {
        document.getElementById("gd").style.display="block";
        document.getElementById("gd").innerHTML='Please Fill it';
    }

    if(cname.match(/[A-Za-z]/g)==null || cname.match(check2))
    {
        document.getElementById("cmp").style.display="block";
        document.getElementById("cmp").innerHTML='Please Fill it';
    }
    
    if(role.match(/[A-Za-z]/g)==null || role.match(jcheck))
    {
        document.getElementById("job").style.display="block";
        document.getElementById("job").innerHTML='Please Fill it';
    }

    if(yoe.match(/[0-9]/g)==null)
    {
        document.getElementById("yr").style.display="block";
        document.getElementById("yr").innerHTML='Please Fill it';
    }

    if(skill.match(/[A-Za-z\s]/g)==null || skill.match(sklcheck))
    {
        document.getElementById("skl").style.display="block";
        document.getElementById("skl").innerHTML='Please Fill it';
    }

    if(ct1.match(/[0-9A-Z]/g)==null)
    {
        document.getElementById("ctc1").style.display="block";
        document.getElementById("ctc1").innerHTML='Please Fill it';
    }

    if(ct2.match(/[0-9A-Z]/g)==null )
    {
        document.getElementById("ctc2").style.display="block";
        document.getElementById("ctc2").innerHTML='Please Fill it';
    }

    if(name.match(/[A-Za-z\s]/g)!= null && mail.match(/[a-z0-9@gmail.com]/g)!=null && phno.match(/[0-9]/g)!=null && role.match(/[A-Za-z]/g)!=null && yoe.match(/[0-9]/g)!=null && skill.match(/[A-Za-z]/g)!=null && dob.match(/[0-9]/g)!=null && ph2.match(/[0-9]/g)!=null && gen.match(/[A-Za-z]/g)!=null && ct1.match(/[0-9A-Z]/g)!=null && ct2.match(/[0-9A-Z]/g)!=null && cname.match(/[A-Za-z]/g)!=null)
    {
        document.getElementById("result").innerHTML="Registered Successfully!!"
        
    }


    /*if(name.match(/[A-Za-z]/g)== null)
    {
        document.getElementById("nm").style.display="block";
        document.getElementById("nm").innerHTML='Please Fill it';
    }
    if(mail.match(/[A-Za-z0-9]+@/g)==null)
    {
        document.getElementById("eml").style.display="block";
        document.getElementById("eml").innerHTML='Please Fill it';
    }
    if(phno.match(/[0-9]{10}/g)==null)
    {
        document.getElementById("num").style.display="block";
        document.getElementById("num").innerHTML='Please Fill it';
    }
    if(role.match(/[A-Za-z]/g)==null)
    {
        document.getElementById("job").style.display="block";
        document.getElementById("job").innerHTML='Please Fill it';
    }
    if(yoe.match(/[0-9]{2}/g)==null)
    {
        document.getElementById("yr").style.display="block";
        document.getElementById("yr").innerHTML='Please Fill it';
    }
    if(skill.match(/[A-Za-z]/g)==null)
    {
        document.getElementById("skl").style.display="block";
        document.getElementById("skl").innerHTML='Please Fill it';
    }*/




    
}

