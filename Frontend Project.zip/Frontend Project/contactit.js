function f1()
{
    let name=document.getElementById("name").value;
    let mail=document.getElementById("mail").value;
    let phno=document.getElementById("ph1").value;

    let check=name.match(/[A-Za-z\s]/g);
    let echeck=mail.match(/[A-Za-z0-9@gmail.com]/g);
    let phcheck=phno.match(/[0-9]/g);

    if(name.match(/[A-Za-z\s]/g)== null || name.match(check))
    {
        document.getElementById("nm").style.display="block";
        document.getElementById("nm").innerHTML='Please Fill it';
    }

    if(mail.match(/[A-Za-z0-9@gmail.com]/g)==null || mail.match(echeck))
    {
        document.getElementById("eml").style.display="block";
        document.getElementById("eml").innerHTML='Please Fill it';
    }

    if(phno.match(/[0-9]/g)==null || phno.match(phcheck))
    {
        document.getElementById("num").style.display="block";
        document.getElementById("num").innerHTML='Please Fill it';
    }

    if(name.match(/[A-Za-z\s]/g)!= null && mail.match(/[a-z0-9@gmail.com]/g)!=null && phno.match(/[0-9]/g)!=null )
    {
        document.getElementById("result").innerHTML="Registered Successfully!!";
        // window.location.href = "./project.html"
    }

}